export default function DiscountPage() {
  return (
    <div>
      <h1>Discount Page</h1>
    </div>
  )
}