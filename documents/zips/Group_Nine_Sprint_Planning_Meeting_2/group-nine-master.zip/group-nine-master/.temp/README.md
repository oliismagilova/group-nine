# Temporary directory

Directory is to store temporary files used during development.
