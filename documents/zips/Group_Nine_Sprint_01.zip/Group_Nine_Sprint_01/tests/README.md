# Test Directory

This directory is to test various features and components for the client side.

Mainly used to test possible Three.JS models to be used on the landing page to add flair.

Any working components can be ported to the production application
