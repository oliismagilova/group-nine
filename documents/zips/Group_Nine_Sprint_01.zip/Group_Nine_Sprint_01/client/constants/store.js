// this file is temporary
import { v4 as uuidv4 } from 'uuid'

module.exports = [
  {
    id: uuidv4(),
    img: 'https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-01.jpg',
    name: 'Bottle',
    price: '35',
    path: '/',
  },
  {
    id: uuidv4(),
    img: 'https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-02.jpg',
    name: 'Tumbler',
    price: '30',
    path: '/store',
  },
  {
    id: uuidv4(),
    img: 'https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-01.jpg',
    name: 'Bottle',
    price: '35',
    path: '/store',
  },
  {
    id: uuidv4(),
    img: 'https://tailwindui.com/img/ecommerce-images/category-page-04-image-card-02.jpg',
    name: 'Tumbler',
    price: '30',
    path: '/store',
  },
]
